const Book = require("../models/Book");

// Add new book (Admin)
exports.addBook = async (req, res) => {
  try {
    const { title, author, isbn, availableCopies } = req.body;

    const bookExists = await Book.findOne({ isbn });
    if (bookExists) {
      return res.status(400).json({ message: "Book already exists" });
    }

    const book = await Book.create({ title, author, isbn, availableCopies });
    res.status(201).json({ message: "Book added", book });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all books (Admin + Student)
exports.getBooks = async (req, res) => {
  try {
    const books = await Book.find();
    res.json({ books });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get book by ID
exports.getBookById = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: "Book not found" });
    res.json({ book });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update book (Admin)
exports.updateBook = async (req, res) => {
  try {
    const { title, author, isbn, availableCopies } = req.body;
    const book = await Book.findByIdAndUpdate(
      req.params.id,
      { title, author, isbn, availableCopies },
      { new: true }
    );
    if (!book) return res.status(404).json({ message: "Book not found" });
    res.json({ message: "Book updated", book });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Delete book (Admin)
exports.deleteBook = async (req, res) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) return res.status(404).json({ message: "Book not found" });
    res.json({ message: "Book deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
    // Soft delete
book.isActive = false;
await book.save();
  }
};
const Borrow = require("../models/Borrow");
const Book = require("../models/Book");

// Borrow book (Student)
exports.borrowBook = async (req, res) => {
  try {
    const { bookId } = req.params;
    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ message: "Book not found" });

    if (book.availableCopies < 1) {
      return res.status(400).json({ message: "No copies available" });
    }

    // Create borrow record
    const borrow = await Borrow.create({
      book: bookId,
      student: req.user.id
    });

    // Reduce available copies
    book.availableCopies -= 1;
    await book.save();

    res.status(201).json({ message: "Book borrowed", borrow });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Return book (Student)
exports.returnBook = async (req, res) => {
  try {
    const { borrowId } = req.params;
    const borrow = await Borrow.findById(borrowId).populate("book");
    if (!borrow) return res.status(404).json({ message: "Borrow record not found" });

    // Ownership check
    if (borrow.student.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not allowed to return this book" });
    }

    if (borrow.status === "returned") {
      return res.status(400).json({ message: "Book already returned" });
    }

    borrow.status = "returned";
    borrow.returnDate = Date.now();
    await borrow.save();

    // Increase available copies
    borrow.book.availableCopies += 1;
    await borrow.book.save();

    res.json({ message: "Book returned", borrow });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// View own borrow history (Student)
exports.getMyHistory = async (req, res) => {
  try {
    const history = await Borrow.find({ student: req.user.id }).populate("book");
    res.json({ history });
  } catch (error) {
    res.status(500).json({ message: error.message });
    // Check overdue books
const overdueBooks = await Borrow.find({
  status: "issued",
  issuedAt: { $lte: new Date(Date.now() - 7*24*60*60*1000) }
});
  }
};
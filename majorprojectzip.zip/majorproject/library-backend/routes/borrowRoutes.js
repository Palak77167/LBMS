const express = require("express");
const router = express.Router();
const { borrowBook, returnBook, getMyHistory } = require("../controllers/borrowController");
const { protect } = require("../middleware/authMiddleware");

// All routes protected, only logged in students
router.post("/borrow/:bookId", protect, borrowBook);
router.patch("/return/:borrowId", protect, returnBook);
router.get("/history", protect, getMyHistory);

module.exports = router;
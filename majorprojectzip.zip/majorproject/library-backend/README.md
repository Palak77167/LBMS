# Library Book Management System (Backend)

## Project Overview
- Secure library management system
- Node.js + Express.js + MongoDB + JWT + RBAC
- Admin & Student roles

## Features
1. Admin: Add/Update/Delete Books
2. Student: Borrow/Return books
3. Borrow history (ownership enforced)
4. Availability check & Overdue tracking
5. Soft delete for books

## Tech Stack
- Node.js, Express.js
- MongoDB (Atlas)
- JWT Authentication
- Bcrypt password hashing
- Role-Based Access Control (RBAC)

## Folder Structure
- models/, routes/, controllers/, middleware/, config/, server.js

## API Routes
- /api/auth/register, /login
- /api/books → Admin + Student
- /api/borrow/:bookId → Student
- /api/return/:borrowId → Student
- /api/history → Student

## Security & Design
- JWT authentication
- Role-based access control
- Ownership enforcement
- Standardized API responses
- Soft delete & Overdue tracking

## Assumptions
- Each borrow period = 7 days
- Admin can view all overdue books
- Students can see only their own history

## How to Run
1. npm install
2. Create .env with MONGO_URI + JWT_SECRET
3. npm run dev
4. Use Postman / frontend to test APIs
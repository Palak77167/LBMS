import React, { useState } from "react";
import "./App.css";
import Login from "./components/Login";
import BookList from "./components/BookList";

function App() {
  const [token, setToken] = useState(null);
  const [role, setRole] = useState(null);

  return (
    <div className="App">
      {!token ? (
        <Login setToken={setToken} setRole={setRole} />
      ) : (
        <BookList token={token} />
      )}
    </div>
  );
}

export default App;

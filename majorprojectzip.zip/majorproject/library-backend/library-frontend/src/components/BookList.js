import React, { useEffect, useState } from "react";

function BookList({ token }) {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/books", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      setBooks(data);
    } catch (err) {
      alert("Error fetching books");
    }
  };

  return (
    <div className="card book-list">
      <h2>Available Books</h2>

      {books.length === 0 && <p>No books available</p>}

      {books.map((book) => (
        <div className="book-item" key={book._id}>
          <span>{book.title}</span> <br />
          Author: {book.author} <br />
          ISBN: {book.isbn} <br />
          Available Copies: {book.availableCopies}
        </div>
      ))}
    </div>
  );
}

export default BookList;